﻿int inventory = 0;
bool exit = true;
int enter;
string command = "null";
int balance = 60;
string moon = "experimentation";
Console.Write("Nickname: ");
string nick = Console.ReadLine();
Console.WriteLine($"Welcome to the Lethal Company Console Edition, {nick}!");
Console.WriteLine();
Console.WriteLine("Loading...");
System.Threading.Thread.Sleep(3000);
while (exit)
{
    Console.WriteLine();
    Console.WriteLine("Choose your option: ");
    Console.WriteLine("Land");
    Console.WriteLine("Terminal");
    Console.WriteLine("info");
    Console.WriteLine();
    string chose = Console.ReadLine();
    switch (chose)
    {
        case "Land":
            Console.WriteLine();
            Console.WriteLine("Landing...");
            System.Threading.Thread.Sleep(3000);
            switch(moon)
            {
                case "experimentation":
                    for (int i = 0; i < 2; i++)
                    {
                        Console.WriteLine("Choose enter: ");
                        Console.WriteLine("1.Main ");
                        Console.WriteLine("2.Fire");
                        enter = int.Parse(Console.ReadLine());
                        switch (enter)
                        {
                            case 1:
                                Console.WriteLine();
                                Console.WriteLine("Loading...");
                                System.Threading.Thread.Sleep(3000);
                                Console.WriteLine("You found some scrap!");
                                balance += 40;
                                inventory += 1;
                                break;
                            case 2:
                                Console.WriteLine();
                                Console.WriteLine("Loading...");
                                System.Threading.Thread.Sleep(3000);
                                Console.WriteLine("You found an easter egg!");
                                balance += 65;
                                break;
                            default:
                                Console.WriteLine("error");
                                break;
                        }
                    }
                    break;
                case "Experimentation":
                    for (int i = 0; i < 2; i++)
                    {
                        Console.WriteLine("Choose enter: ");
                        Console.WriteLine("1.Main ");
                        Console.WriteLine("2.Fire");
                        enter = int.Parse(Console.ReadLine());
                        switch (enter)
                        {
                            case 1:
                                Console.WriteLine();
                                Console.WriteLine("Loading...");
                                System.Threading.Thread.Sleep(3000);
                                Console.WriteLine("You found some scrap!");
                                balance += 40;
                                inventory += 1;
                                break;
                            case 2:
                                Console.WriteLine();
                                Console.WriteLine("Loading...");
                                System.Threading.Thread.Sleep(3000);
                                Console.WriteLine("You found an easter egg!");
                                balance += 65;
                                break;
                            default:
                                Console.WriteLine("error");
                                break;
                        }
                    }
                    break;

            }
            break;
        case "land":
            Console.WriteLine();
            Console.WriteLine("Landing...");
            System.Threading.Thread.Sleep(3000);
            switch (moon)
            {
                case "experimentation":
                    for (int i = 0; i < 2; i++)
                    {
                        Console.WriteLine("Choose enter: ");
                        Console.WriteLine("1.Main ");
                        Console.WriteLine("2.Fire");
                        enter = int.Parse(Console.ReadLine());
                        switch (enter)
                        {
                            case 1:
                                Console.WriteLine();
                                Console.WriteLine("Loading...");
                                System.Threading.Thread.Sleep(3000);
                                Console.WriteLine("You found some scrap!");
                                balance += 40;
                                inventory += 1;
                                break;
                            case 2:
                                Console.WriteLine();
                                Console.WriteLine("Loading...");
                                System.Threading.Thread.Sleep(3000);
                                Console.WriteLine("You found an easter egg!");
                                balance += 65;
                                break;
                            default:
                                Console.WriteLine("error");
                                break;
                        }
                    }
                    break;
                case "Experimentation":
                    for (int i = 0; i < 2; i++)
                    {
                        Console.WriteLine("Choose enter: ");
                        Console.WriteLine("1.Main ");
                        Console.WriteLine("2.Fire");
                        enter = int.Parse(Console.ReadLine());
                        switch (enter)
                        {
                            case 1:
                                Console.WriteLine();
                                Console.WriteLine("Loading...");
                                System.Threading.Thread.Sleep(3000);
                                Console.WriteLine("You found some scrap!");
                                balance += 40;
                                inventory += 1;
                                break;
                            case 2:
                                Console.WriteLine();
                                Console.WriteLine("Loading...");
                                System.Threading.Thread.Sleep(3000);
                                Console.WriteLine("You found an easter egg!");
                                balance += 65;
                                break;
                            default:
                                Console.WriteLine("error");
                                break;
                        }
                    }
                    break;

            }
            break;
        case "terminal":
            Console.WriteLine();
            Console.WriteLine($"Balance: {balance}");
            Console.WriteLine();
            Console.WriteLine("type command help to know the commands.");
            Console.WriteLine();
            Console.WriteLine();
            Console.Write("Input: ");
            command = Console.ReadLine();
            switch (command)
            {
                case "help":
                    Console.WriteLine("Moons");
                    Console.WriteLine("To see list of moons the autopilot can route to.");
                    Console.WriteLine();
                    Console.WriteLine("Store");
                    Console.WriteLine("To see the company store`s selection of useful items.");
                    Console.WriteLine();
                    Console.WriteLine("Exit");
                    Console.WriteLine("To exit.");
                    break;
                case "moons":
                    Console.WriteLine("Welcome to the exomoons catalogue." + "To route the autopilot ship to a moon, use a word ROUTE.");
                    Console.WriteLine();
                    Console.WriteLine();
                    Console.WriteLine("* Experimantation");
                    break;
                case "Moons":
                    Console.WriteLine("Welcome to the exomoons catalogue." + "To route the autopilot ship to a moon, use a word ROUTE.");
                    Console.WriteLine();
                    Console.WriteLine();
                    Console.WriteLine("* Experimentation");
                    break;
                case "store":
                    Console.WriteLine();
                    Console.WriteLine("nothing...");
                    break;
                case "Store":
                    Console.WriteLine();
                    Console.WriteLine("nothing...");
                    break;
                case "exit":
                    exit = false;
                    break;
                case "Exit":
                    exit = false;
                    break;
                default:
                    Console.WriteLine("error");
                    break;
            }

            break;
        case "Terminal":
            Console.WriteLine();
            Console.WriteLine($"Balance: {balance}");
            Console.WriteLine();
            Console.WriteLine("type command help to know the commands.");
            Console.WriteLine();
            Console.WriteLine();
            Console.Write("Input: ");
            command = Console.ReadLine();
            switch (command)
            {
                case "help":
                    Console.WriteLine("Moons");
                    Console.WriteLine("To see list of moons the autopilot can route to.");
                    Console.WriteLine();
                    Console.WriteLine("Store");
                    Console.WriteLine("To see the company store`s selection of useful items.");
                    Console.WriteLine();
                    Console.WriteLine("Exit");
                    Console.WriteLine("To exit.");
                    break;
                case "moons":
                    Console.WriteLine("Welcome to the exomoons catalogue." + "To route the autopilot ship to a moon, use a word ROUTE.");
                    Console.WriteLine();
                    Console.WriteLine();
                    Console.WriteLine("* Experimantation");
                    break;
                case "Moons":
                    Console.WriteLine("Welcome to the exomoons catalogue." + "To route the autopilot ship to a moon, use a word ROUTE.");
                    Console.WriteLine();
                    Console.WriteLine();
                    Console.WriteLine("* Experimantation");
                    break;
                case "store":
                    Console.WriteLine();
                    Console.WriteLine("nothing...");
                    break;
                case "Store":
                    Console.WriteLine();
                    Console.WriteLine("nothing...");
                    break;
                case "exit":
                    exit = false;
                    break;
                case "Exit":
                    exit = false;
                    break;
                default:
                    Console.WriteLine("error");
                    break;
            }

            break;
        case "info":
            Console.WriteLine();
            Console.WriteLine("It is an fan project by Wonchik");
            break;

    }
}
